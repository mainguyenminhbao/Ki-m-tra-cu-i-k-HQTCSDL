--Câu Câu1 a Tạo các login; tạo các user khai thác CSDL AdventureWorks2008R2 cho các nhân viên (tên login trùng tên user)
-- Tạo login cho nhân viên NV1 và NV2
CREATE LOGIN NV1 WITH PASSWORD = 'nv1_password';
CREATE LOGIN NV2 WITH PASSWORD = 'nv2_password';
select * From 
-- Tạo user cho nhân viên NV1 và NV2
USE AdventureWorks2008R2;
CREATE USER NV1 FOR LOGIN NV1 WITH DEFAULT_SCHEMA = dbo;
CREATE USER NV2 FOR LOGIN NV2 WITH DEFAULT_SCHEMA = dbo;

-- Tạo user cho nhân viên quản lý QL
CREATE LOGIN QL WITH PASSWORD = 'ql_password';
USE AdventureWorks2008R2;
CREATE USER QL FOR LOGIN QL WITH DEFAULT_SCHEMA = dbo;
GRANT SELECT ON PersonPhone, Person TO QL;
 

--Câu1B ----
-- Tạo role NhanVien
USE AdventureWorks2008R2;
CREATE ROLE NhanVien;

-- Phân quyền cho role NhanVien
GRANT SELECT, INSERT, UPDATE, DELETE ON PersonPhone TO NhanVien;

-- Thêm user NV1 và NV2 vào role NhanVien
ALTER ROLE NhanVien ADD MEMBER NV1;
ALTER ROLE NhanVien ADD MEMBER NV2;

ALTER ROLE NhanVien ADD MEMBER QL;

-- Tạo role QL_Role
USE AdventureWorks2008R2;
CREATE ROLE QL_Role;

-- Phân quyền cho role QL_Role
GRANT SELECT ON PersonPhone, Person TO QL_Role;

-- Thêm user QL vào role QL_Role
ALTER ROLE QL_Role ADD MEMBER QL;


--2

-- Full backup
BACKUP DATABASE AdventureWorks2008R2 TO DISK = '[path/to/full/backup/file]' WITH INIT;

-- Thực hiện tăng lương cho nhân viên
UPDATE HumanResources.Employee
SET Rate = CASE
            WHEN DepartmentID IN (
              SELECT DepartmentID FROM HumanResources.Department WHERE Name IN ('Production', 'Production Control')
            ) THEN Rate * 1.2
            ELSE Rate * 1.15
          END;