--Câu1c--

-- Đăng nhập với tài khoản NV1
USE AdventureWorks2008R2;

-- Sửa số điện thoại của người có BusinessEntityID=(3 ký tự cuối của Mã SV của chính SV dự thi) thành 123-456-7890
UPDATE PersonPhone
SET PhoneNumber = '123-456-7890'
WHERE BusinessEntityID = RIGHT('085',3);
