--1d. Ai có thể xem dữ liệu bảng Person.Person? Giải thích. Viết lệnh kiểm tra quyền trên cửa sổ query của user tương ứng (1đ).

--Theo phân quyền đã định nghĩa ở câu hỏi trước, chỉ có nhân viên QL được phép xem dữ liệu bảng Person.Person. Vì user QL được phân quyền db_datareader, làm việc trên bảng PersonPhone và bảng Person, nên chỉ có quyền SELECT trên 2 bảng này.

--Để kiểm tra quyền của user QL trên cửa sổ query, bạn có thể sử dụng câu lệnh sau:
-- Kiểm tra quyền của user QL
USE AdventureWorks2008R2;
SELECT * FROM fn_my_permissions('Person.Person', 'OBJECT');

--1e Các nhân viên quản lý NV1, NV2, QL hoàn thành dự án, admin thu hồi quyền đã cấp. Xóa role NhanVien.
--Thu hồi quyền của NV1, NV2, QL:

-- Đăng nhập với tài khoản admin
USE AdventureWorks2008R2;

-- Thu hồi quyền của NV1, NV2, QL
ALTER ROLE NhanVien DROP MEMBER NV1;
ALTER ROLE NhanVien DROP MEMBER NV2;
ALTER ROLE NhanVien DROP MEMBER QL;

-- Xóa role NhanVien
DROP ROLE NhanVien;
