
--Câu Câu1 a Tạo các login; tạo các user khai thác CSDL AdventureWorks2008R2 cho các nhân viên (tên login trùng tên user)
-- Tạo login cho nhân viên NV1 và NV2
CREATE LOGIN NV1 WITH PASSWORD = 'nv1_password';
CREATE LOGIN NV2 WITH PASSWORD = 'nv2_password';
select * From 
-- Tạo user cho nhân viên NV1 và NV2
USE AdventureWorks2008R2;
CREATE USER NV1 FOR LOGIN NV1 WITH DEFAULT_SCHEMA = dbo;
CREATE USER NV2 FOR LOGIN NV2 WITH DEFAULT_SCHEMA = dbo;

-- Tạo user cho nhân viên quản lý QL
CREATE LOGIN QL WITH PASSWORD = 'ql_password';
USE AdventureWorks2008R2;
CREATE USER QL FOR LOGIN QL WITH DEFAULT_SCHEMA = dbo;
GRANT SELECT ON PersonPhone, Person TO QL;
 

--Câu1B ----
-- Tạo role NhanVien
USE AdventureWorks2008R2;
CREATE ROLE NhanVien;

-- Phân quyền cho role NhanVien
GRANT SELECT, INSERT, UPDATE, DELETE ON PersonPhone TO NhanVien;

-- Thêm user NV1 và NV2 vào role NhanVien
ALTER ROLE NhanVien ADD MEMBER NV1;
ALTER ROLE NhanVien ADD MEMBER NV2;

ALTER ROLE NhanVien ADD MEMBER QL;

-- Tạo role QL_Role
USE AdventureWorks2008R2;
CREATE ROLE QL_Role;

-- Phân quyền cho role QL_Role
GRANT SELECT ON PersonPhone, Person TO QL_Role;

-- Thêm user QL vào role QL_Role
ALTER ROLE QL_Role ADD MEMBER QL;

--Câu1c--

-- Đăng nhập với tài khoản NV1
USE AdventureWorks2008R2;

-- Sửa số điện thoại của người có BusinessEntityID=(3 ký tự cuối của Mã SV của chính SV dự thi) thành 123-456-7890
UPDATE PersonPhone
SET PhoneNumber = '123-456-7890'
WHERE BusinessEntityID = RIGHT('085',3);

-- Đăng nhập với tài khoản NV2
USE AdventureWorks2008R2;

-- Xóa số điện thoại của người có BusinessEntityID=(3 ký tự đầu của Mã SV của chính SV dự thi)
DELETE PersonPhone
WHERE BusinessEntityID = LEFT('085', 3);

-- Đăng nhập với tài khoản QL
USE AdventureWorks2008R2;

-- Xem lại kết quả NV1 và NV2 đã làm
SELECT *
FROM PersonPhone;

--1d. Ai có thể xem dữ liệu bảng Person.Person? Giải thích. Viết lệnh kiểm tra quyền trên cửa sổ query của user tương ứng (1đ).

--Theo phân quyền đã định nghĩa ở câu hỏi trước, chỉ có nhân viên QL được phép xem dữ liệu bảng Person.Person. Vì user QL được phân quyền db_datareader, làm việc trên bảng PersonPhone và bảng Person, nên chỉ có quyền SELECT trên 2 bảng này.

--Để kiểm tra quyền của user QL trên cửa sổ query, bạn có thể sử dụng câu lệnh sau:
-- Kiểm tra quyền của user QL
USE AdventureWorks2008R2;
SELECT * FROM fn_my_permissions('Person.Person', 'OBJECT');

--1e Các nhân viên quản lý NV1, NV2, QL hoàn thành dự án, admin thu hồi quyền đã cấp. Xóa role NhanVien.
--Thu hồi quyền của NV1, NV2, QL:

-- Đăng nhập với tài khoản admin
USE AdventureWorks2008R2;

-- Thu hồi quyền của NV1, NV2, QL
ALTER ROLE NhanVien DROP MEMBER NV1;
ALTER ROLE NhanVien DROP MEMBER NV2;
ALTER ROLE NhanVien DROP MEMBER QL;

-- Xóa role NhanVien
DROP ROLE NhanVien;

--2

-- Full backup
BACKUP DATABASE AdventureWorks2008R2 TO DISK = '[path/to/full/backup/file]' WITH INIT;

-- Thực hiện tăng lương cho nhân viên
UPDATE HumanResources.Employee
SET Rate = CASE
            WHEN DepartmentID IN (
              SELECT DepartmentID FROM HumanResources.Department WHERE Name IN ('Production', 'Production Control')
            ) THEN Rate * 1.2
            ELSE Rate * 1.15
          END;


--3 Viết after trigger trên bảng ProductReview sao cho khi cập nhật 1 bình luận (Comments) cho 1 mã sản phẩm đã có thì liệt kê danh sách thông tin liên quan của sản phẩm gồm ProductID, Color, StandardCost, Rating, Comments; nếu mã sản phẩm không có thì báo lỗi và quay lui giao tác. Viết lệnh kích hoạt trigger cho 2trường hợp trên .
CREATE TRIGGER trg_UpdateProductReviewComments
ON ProductReview
AFTER UPDATE
AS
BEGIN
  IF UPDATE(Comments)
  BEGIN
    DECLARE @ProductID INT;
    SELECT @ProductID = i.ProductID
    FROM inserted i
    INNER JOIN deleted d ON i.ProductReviewID = d.ProductReviewID;

    IF NOT EXISTS (SELECT * FROM Product WHERE ProductID = @ProductID)
    BEGIN
      RAISERROR('ProductID %d không tồn tại!', 16, 1, @ProductID);
      ROLLBACK TRANSACTION;
      RETURN;
    END

    SELECT p.ProductID, p.Color, p.StandardCost, pr.Rating, pr.Comments
    FROM Product p
    INNER JOIN ProductReview pr ON p.ProductID = pr.ProductID
    WHERE p.ProductID = @ProductID;
  END
END

--Kích hoạt trigger khi cập nhật bình luận cho sản phẩm có mã ID là 100:

USE AdventureWorks2008R2;
UPDATE ProductReview SET Comments = 'Đánh giá mới cho sản phẩm này' WHERE ProductID = 100;

--Kích hoạt trigger khi cập nhật bình luận cho sản phẩm có mã ID là 999 (mã sản phẩm không tồn tại):

USE AdventureWorks2008R2;
UPDATE ProductReview SET Comments = 'Đánh giá mới cho sản phẩm này' WHERE ProductID = 999;
